// Supabase > Project Settings > API. Use only the public anon/publishable key.
window.BIG4_CONFIG={supabaseUrl:"YOUR_SUPABASE_PROJECT_URL",supabaseAnonKey:"YOUR_SUPABASE_ANON_OR_PUBLISHABLE_KEY"};
