BIG_4 CORPORATE WEBSITE UPGRADE

Includes:
- Multi-page corporate site: Home, About, Services, Industries, Insights, Contact.
- Client sign-up/login, client dashboard, service request form and private document upload.
- Admin dashboard for client profiles, requests, projects and invoices.
- Supabase SQL with Row Level Security and private file storage policies.
- Homepage 30-second video element (muted autoplay + loop).

ACTIVATION REQUIRED:
This is a deployable starter package, but client accounts/database/file storage are NOT live until Supabase is configured.

1) Create a Supabase project.
2) Run all of supabase_setup.sql in Supabase SQL Editor.
3) Copy Project URL and public anon/publishable key from Project Settings > API into config.js.
4) Sign up with your own email.
5) In Supabase Authentication > Users, copy your user UUID and run:
   update public.profiles set role='admin' where id='YOUR-REAL-USER-UUID';
6) Add a licensed 30-second MP4 named assets/hero-30s.mp4. Homepage already autoplays muted, loops and uses a poster fallback.
7) Upload the folder contents (index.html at root) to your existing Netlify site.

Security:
- Do not use a service_role key in browser files.
- Client table access is protected by RLS: clients see only their own records; admin role can see all.
- Documents are in a private bucket with per-user folder restrictions.
- Admin dashboard currently displays records. Add/edit project and invoice records through Supabase Table Editor; a full admin editing interface is a next phase.
- Enable email confirmation and configure Netlify URL in Supabase Auth URL settings before launch.
- Replace placeholder contact email with your verified agency email.
