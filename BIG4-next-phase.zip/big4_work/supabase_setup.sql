
-- BIG_4 Supabase setup: run in Supabase SQL Editor.
create extension if not exists pgcrypto;
create table if not exists public.profiles(
 id uuid primary key references auth.users(id) on delete cascade,
 full_name text,email text,phone text,company_name text,country text,
 role text not null default 'client' check(role in ('client','admin')),
 created_at timestamptz not null default now()
);
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path=public as $$
begin
 insert into public.profiles(id,full_name,email,phone,company_name,country)
 values(new.id,new.raw_user_meta_data->>'full_name',new.email,new.raw_user_meta_data->>'phone',new.raw_user_meta_data->>'company_name',new.raw_user_meta_data->>'country')
 on conflict(id) do nothing; return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

create table if not exists public.client_requests(
 id uuid primary key default gen_random_uuid(),user_id uuid not null references public.profiles(id) on delete cascade,
 subject text not null,service_type text,description text not null,document_path text,
 status text not null default 'Received',created_at timestamptz not null default now()
);
create table if not exists public.projects(
 id uuid primary key default gen_random_uuid(),client_id uuid not null references public.profiles(id) on delete cascade,
 project_name text not null,status text not null default 'In progress',updated_at timestamptz not null default now(),created_at timestamptz not null default now()
);
create table if not exists public.invoices(
 id uuid primary key default gen_random_uuid(),client_id uuid not null references public.profiles(id) on delete cascade,
 invoice_number text not null,amount numeric(12,2) not null default 0,currency text not null default 'USD',
 status text not null default 'Unpaid',due_date date,created_at timestamptz not null default now()
);
create table if not exists public.public_inquiries(
 id uuid primary key default gen_random_uuid(),name text not null,email text not null,message text not null,created_at timestamptz not null default now()
);
create or replace function public.is_big4_admin() returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.profiles where id=auth.uid() and role='admin'); $$;

alter table public.profiles enable row level security;
alter table public.client_requests enable row level security;
alter table public.projects enable row level security;
alter table public.invoices enable row level security;
alter table public.public_inquiries enable row level security;

create policy "profile own or admin read" on public.profiles for select to authenticated using(id=auth.uid() or public.is_big4_admin());
-- Only admins can update profile rows. This prevents clients from changing their own role to admin.
create policy "admin update profiles" on public.profiles for update to authenticated using(public.is_big4_admin()) with check(public.is_big4_admin());
create policy "request own or admin read" on public.client_requests for select to authenticated using(user_id=auth.uid() or public.is_big4_admin());
create policy "client create own request" on public.client_requests for insert to authenticated with check(user_id=auth.uid());
create policy "admin update requests" on public.client_requests for update to authenticated using(public.is_big4_admin()) with check(public.is_big4_admin());
create policy "project own or admin read" on public.projects for select to authenticated using(client_id=auth.uid() or public.is_big4_admin());
create policy "admin manage projects" on public.projects for all to authenticated using(public.is_big4_admin()) with check(public.is_big4_admin());
create policy "invoice own or admin read" on public.invoices for select to authenticated using(client_id=auth.uid() or public.is_big4_admin());
create policy "admin manage invoices" on public.invoices for all to authenticated using(public.is_big4_admin()) with check(public.is_big4_admin());
create policy "public enquiry insert" on public.public_inquiries for insert to anon,authenticated with check(true);
create policy "admin enquiry read" on public.public_inquiries for select to authenticated using(public.is_big4_admin());

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('client-documents','client-documents',false,10485760,array['application/pdf','image/png','image/jpeg','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','text/csv','application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document'])
on conflict(id) do update set public=false,file_size_limit=10485760;
create policy "client upload own folder" on storage.objects for insert to authenticated
with check(bucket_id='client-documents' and (storage.foldername(name))[1]=auth.uid()::text);
create policy "client read own or admin files" on storage.objects for select to authenticated
using(bucket_id='client-documents' and ((storage.foldername(name))[1]=auth.uid()::text or public.is_big4_admin()));

-- After you create your own account, copy its UUID from Authentication > Users, then run:
-- update public.profiles set role='admin' where id='YOUR-REAL-USER-UUID';
-- Never put the Supabase service_role key in config.js or public website code.


-- Employee applications: submitted applications are visible to authorized admins only.
create table if not exists public.employee_applications(
 id uuid primary key default gen_random_uuid(), full_name text not null, email text not null, phone text not null,
 position text not null, qualification text not null, experience text not null, skills text not null,
 message text, status text not null default 'Received', created_at timestamptz not null default now()
);
alter table public.employee_applications enable row level security;
create policy "public submit employee application" on public.employee_applications for insert to anon,authenticated with check(true);
create policy "admin read employee applications" on public.employee_applications for select to authenticated using(public.is_big4_admin());
create policy "admin update employee applications" on public.employee_applications for update to authenticated using(public.is_big4_admin()) with check(public.is_big4_admin());
